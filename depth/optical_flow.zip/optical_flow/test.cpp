#include<iostream>
#include<opencv2/opencv.hpp>
#include<shrink.hpp>
using namespace std;
using namespace cv;
using namespace huroiitk;

int main(){ 
	Mat src, dest;
	src = imread("test_img.jpg", 0);
	shrink(src, dest);
	namedWindow("src");
	namedWindow("dest");
	imshow("src",  src);
	imshow("dest", dest);
	waitKey(0);
	return 0;
}
